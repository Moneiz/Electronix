var struct_grid___manager =
[
    [ "components", "struct_grid___manager.html#aebc8d7dee530691a98110b560a0a539a", null ],
    [ "focusX", "struct_grid___manager.html#a29880511b1b24e566a2d42e324851808", null ],
    [ "focusY", "struct_grid___manager.html#a4bef399ed4866fa6c7eb0b19804c9abf", null ],
    [ "nbComponents", "struct_grid___manager.html#a7c5cddb1d792cab8d34c1075438b2f33", null ],
    [ "selectedComponent", "struct_grid___manager.html#ae0966c1547e744296b203db2c0d06abe", null ],
    [ "zoomLevel", "struct_grid___manager.html#a3ff249d3d55c32908f1a3838a3ff5e52", null ]
];