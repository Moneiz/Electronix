var ui_event_8c =
[
    [ "getIdButtonOn", "ui_event_8c.html#aebf9c1126411f6943f7c7020d98b1eb1", null ],
    [ "inputTxtListener", "ui_event_8c.html#a9f8a1139c195d719c39c76a37accba91", null ]
];