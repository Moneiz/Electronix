var list_helper_8h =
[
    [ "addItem", "list_helper_8h.html#a60d97bd161317b13f80d773b276e2226", null ],
    [ "getComponentByPos", "list_helper_8h.html#a70142d1f266116b07a823feec0979f9b", null ],
    [ "listToArray", "list_helper_8h.html#a2ebb421af0889e87c8793704b57a9d9b", null ],
    [ "removeItemAt", "list_helper_8h.html#af0f01c2dbe574864203f6afb6ff1b14f", null ],
    [ "reverseComponent", "list_helper_8h.html#aed5b7d602616f1215e639c06ac7d2445", null ],
    [ "setSpecificDataComponent", "list_helper_8h.html#aef6a1c2c2de1abc2df4156b5bad5d1ca", null ]
];