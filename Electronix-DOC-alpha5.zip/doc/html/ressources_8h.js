var ressources_8h =
[
    [ "Ressources", "struct_ressources.html", "struct_ressources" ],
    [ "NB_IMAGES", "ressources_8h.html#a40ae068cc2b70374bc3bf234a40caab4", null ],
    [ "NB_TEXT", "ressources_8h.html#a10472644c61b69669a3fcfde6c1f4d10", null ],
    [ "Ressources", "ressources_8h.html#a61c35e8bab8a8e02043f5b984ab349a1", null ],
    [ "getFilledRessources", "ressources_8h.html#a6815b293634bf4b67a5fbfddd8a10468", null ]
];