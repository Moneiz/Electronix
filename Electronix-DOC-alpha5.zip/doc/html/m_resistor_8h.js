var m_resistor_8h =
[
    [ "resistor_drawComponent", "m_resistor_8h.html#a23fc8b451a3aca15e5bff60c7814f87e", null ],
    [ "setColorFromInt", "m_resistor_8h.html#afaf7cc57d33a59099c3bc467b40b984e", null ],
    [ "turnInfo", "m_resistor_8h.html#af41454cc90722a02143d3f44314581dc", null ]
];