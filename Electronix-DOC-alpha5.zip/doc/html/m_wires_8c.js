var m_wires_8c =
[
    [ "wire_calculate", "m_wires_8c.html#ac79e83ff4f240a5eb632c6ddcd3c0577", null ],
    [ "wire_drawComponent", "m_wires_8c.html#a022ab842e02e2e6fcf1efd10c3b5b4c3", null ]
];