var struct_u_i__manager =
[
    [ "nbBt", "struct_u_i__manager.html#a49424ae1afc9e8b73caefab9db14ba36", null ],
    [ "rectBt", "struct_u_i__manager.html#a1e14e727e29eaca7cf3f697b4496d83d", null ],
    [ "rectGroup", "struct_u_i__manager.html#a459174f6e9f0f0501699660adb7d038d", null ]
];