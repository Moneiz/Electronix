var struct_item_component =
[
    [ "component", "struct_item_component.html#a73d788dfb4511b6c4bdd9a857966b620", null ],
    [ "next", "struct_item_component.html#ad9e9b0134540630e749d6bca3fe11557", null ]
];