var ui_manager_8h =
[
    [ "UI_manager", "struct_u_i__manager.html", "struct_u_i__manager" ],
    [ "UI_manager", "ui_manager_8h.html#af59b3e331aebcb1b33b313cf5b515638", null ]
];