var searchData=
[
  ['focusx',['focusX',['../struct_grid___manager.html#a29880511b1b24e566a2d42e324851808',1,'Grid_Manager']]],
  ['focusy',['focusY',['../struct_grid___manager.html#a4bef399ed4866fa6c7eb0b19804c9abf',1,'Grid_Manager']]],
  ['fontspath',['fontsPath',['../struct_config.html#a270f55e1d49965f2da6760f335fb9eb7',1,'Config']]],
  ['fullscreen',['fullscreen',['../struct_config.html#adc359d0ba0a207e69da999c40bf762c8',1,'Config']]]
];
