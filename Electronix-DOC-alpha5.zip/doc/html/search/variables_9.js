var searchData=
[
  ['savespath',['savesPath',['../struct_config.html#adc6000951d279f41265d132f8926a4fb',1,'Config']]],
  ['selectedcomponent',['selectedComponent',['../struct_grid___manager.html#ae0966c1547e744296b203db2c0d06abe',1,'Grid_Manager']]],
  ['specificdata',['specificData',['../struct_component.html#a45788d4c064f4b541e79c588e5355402',1,'Component']]],
  ['statemodule',['stateModule',['../struct_component.html#aea055f43cfad2f78accfbc769ff874bb',1,'Component']]]
];
