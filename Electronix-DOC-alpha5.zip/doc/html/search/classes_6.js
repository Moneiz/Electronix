var searchData=
[
  ['ui_5fmanager',['UI_manager',['../struct_u_i__manager.html',1,'']]]
];
