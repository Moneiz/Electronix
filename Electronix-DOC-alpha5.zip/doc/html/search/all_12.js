var searchData=
[
  ['ui_5fmanager',['UI_manager',['../struct_u_i__manager.html',1,'UI_manager'],['../ui_manager_8h.html#af59b3e331aebcb1b33b313cf5b515638',1,'UI_manager():&#160;uiManager.h']]],
  ['uievent_2ec',['uiEvent.c',['../ui_event_8c.html',1,'']]],
  ['uievent_2eh',['uiEvent.h',['../ui_event_8h.html',1,'']]],
  ['uimanager_2ec',['uiManager.c',['../ui_manager_8c.html',1,'']]],
  ['uimanager_2eh',['uiManager.h',['../ui_manager_8h.html',1,'']]],
  ['upchoose',['upChoose',['../struct_config.html#a00b8c17a020358009c38f139be002545',1,'Config']]],
  ['updateapp',['updateApp',['../kernel_8c.html#a7c80e5cba74a4b6b33813ff506b517ab',1,'updateApp(SDL_Window *windowP, SDL_Renderer *rendererP, Datas datas):&#160;kernel.c'],['../kernel_8h.html#a7c80e5cba74a4b6b33813ff506b517ab',1,'updateApp(SDL_Window *windowP, SDL_Renderer *rendererP, Datas datas):&#160;kernel.c']]],
  ['updateevent',['updateEvent',['../layout_loader_8c.html#abdb7725d2172a065b489d3ad58669532',1,'updateEvent(SDL_Event event, SDL_Window *windowP, SDL_Renderer *rendererP, Datas *datas, int *running):&#160;layoutLoader.c'],['../layout_loader_8h.html#abdb7725d2172a065b489d3ad58669532',1,'updateEvent(SDL_Event event, SDL_Window *windowP, SDL_Renderer *rendererP, Datas *datas, int *running):&#160;layoutLoader.c']]],
  ['updaterender',['updateRender',['../layout_loader_8c.html#a03415311fbae343a14204003e70a004f',1,'updateRender(SDL_Window *windowP, SDL_Renderer *rendererP, Datas datas):&#160;layoutLoader.c'],['../layout_loader_8h.html#a03415311fbae343a14204003e70a004f',1,'updateRender(SDL_Window *windowP, SDL_Renderer *rendererP, Datas datas):&#160;layoutLoader.c']]],
  ['updatestatecomponents',['updateStateComponents',['../module_loader_8c.html#a0cb4e1b841f428492b9baab65e8d1acb',1,'updateStateComponents(ItemComponent *component, Datas *datas, int recursive):&#160;moduleLoader.c'],['../module_loader_8h.html#a0cb4e1b841f428492b9baab65e8d1acb',1,'updateStateComponents(ItemComponent *component, Datas *datas, int recursive):&#160;moduleLoader.c']]]
];
