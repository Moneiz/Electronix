var searchData=
[
  ['surfaces_5fmanager',['Surfaces_manager',['../struct_surfaces__manager.html',1,'']]]
];
