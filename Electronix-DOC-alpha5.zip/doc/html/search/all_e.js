var searchData=
[
  ['postinit',['postInit',['../kernel_8c.html#aefe5df88c57d4b9a356721c015cf1fd6',1,'postInit(SDL_Renderer *rendererP, Datas *datas, Ressources r):&#160;kernel.c'],['../kernel_8h.html#aefe5df88c57d4b9a356721c015cf1fd6',1,'postInit(SDL_Renderer *rendererP, Datas *datas, Ressources r):&#160;kernel.c']]],
  ['posx',['posX',['../struct_component.html#a767e5fff82d910cc62dbb32105a831be',1,'Component']]],
  ['posy',['posY',['../struct_component.html#a1a549fe2e17a9141ee8b37f062491c11',1,'Component']]],
  ['ptrfctcalculate',['ptrFctCalculate',['../struct_module.html#ad12c3e73115b0d819ec4933d324757de',1,'Module']]],
  ['ptrfctrender',['ptrFctRender',['../struct_module.html#a7a2639b6dbb59b82a9e0c2e6dc6b48da',1,'Module']]]
];
