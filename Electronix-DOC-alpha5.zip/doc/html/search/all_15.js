var searchData=
[
  ['zoomlevel',['zoomLevel',['../struct_grid___manager.html#a3ff249d3d55c32908f1a3838a3ff5e52',1,'Grid_Manager']]]
];
