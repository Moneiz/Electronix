var searchData=
[
  ['nb_5fimages',['NB_IMAGES',['../ressources_8h.html#a40ae068cc2b70374bc3bf234a40caab4',1,'ressources.h']]],
  ['nb_5ftext',['NB_TEXT',['../ressources_8h.html#a10472644c61b69669a3fcfde6c1f4d10',1,'ressources.h']]]
];
