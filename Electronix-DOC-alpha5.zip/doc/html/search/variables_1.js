var searchData=
[
  ['downchoose',['downChoose',['../struct_config.html#a2067791600b8b0e36963e29bd61391f1',1,'Config']]]
];
