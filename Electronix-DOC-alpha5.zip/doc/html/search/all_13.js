var searchData=
[
  ['valuetocolor',['valueToColor',['../m_resistor_8c.html#aaded36efbd6f3e08812954202374ef35',1,'mResistor.c']]]
];
