var searchData=
[
  ['wire_5fcalculate',['wire_calculate',['../m_wires_8c.html#ac79e83ff4f240a5eb632c6ddcd3c0577',1,'wire_calculate(Component component, int src, Datas *datas):&#160;mWires.c'],['../m_wires_8h.html#ac79e83ff4f240a5eb632c6ddcd3c0577',1,'wire_calculate(Component component, int src, Datas *datas):&#160;mWires.c']]],
  ['wire_5fdrawcomponent',['wire_drawComponent',['../m_wires_8c.html#a022ab842e02e2e6fcf1efd10c3b5b4c3',1,'wire_drawComponent(SDL_Rect currentRect, Component currentComponent, int idTex, SDL_Renderer *rendererP, Datas datas):&#160;mWires.c'],['../m_wires_8h.html#a022ab842e02e2e6fcf1efd10c3b5b4c3',1,'wire_drawComponent(SDL_Rect currentRect, Component currentComponent, int idTex, SDL_Renderer *rendererP, Datas datas):&#160;mWires.c']]]
];
