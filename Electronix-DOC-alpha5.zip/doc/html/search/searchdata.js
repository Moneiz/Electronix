var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvwz",
  1: "cgimstu",
  2: "abcgiklmrstu",
  3: "abcdefgilmoprstuvw",
  4: "cdfhimnprstuwz",
  5: "cdgimstu",
  6: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Structures de données",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Définitions de type",
  6: "Pages"
};

