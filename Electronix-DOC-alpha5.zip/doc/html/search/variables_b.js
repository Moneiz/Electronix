var searchData=
[
  ['upchoose',['upChoose',['../struct_config.html#a00b8c17a020358009c38f139be002545',1,'Config']]]
];
