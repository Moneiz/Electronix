var searchData=
[
  ['postinit',['postInit',['../kernel_8c.html#aefe5df88c57d4b9a356721c015cf1fd6',1,'postInit(SDL_Renderer *rendererP, Datas *datas, Ressources r):&#160;kernel.c'],['../kernel_8h.html#aefe5df88c57d4b9a356721c015cf1fd6',1,'postInit(SDL_Renderer *rendererP, Datas *datas, Ressources r):&#160;kernel.c']]]
];
