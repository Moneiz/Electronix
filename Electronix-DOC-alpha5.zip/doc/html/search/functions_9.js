var searchData=
[
  ['main',['main',['../main_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main.c']]],
  ['menu_5fend',['menu_end',['../i_menu_8c.html#a16c79ce4eea6a9286541a3c2447ecd1b',1,'menu_end(Datas *datas):&#160;iMenu.c'],['../i_menu_8h.html#a16c79ce4eea6a9286541a3c2447ecd1b',1,'menu_end(Datas *datas):&#160;iMenu.c']]],
  ['menu_5fevent',['menu_event',['../i_menu_8c.html#aa8142218663330ead3358c75506cadde',1,'menu_event(SDL_Event event, SDL_Window *windowP, SDL_Renderer *rendererP, Datas *datas, int *running):&#160;iMenu.c'],['../i_menu_8h.html#a546546b61fc8e75b1caa83941f1282ce',1,'menu_event(SDL_Event event, SDL_Window *windowP, SDL_Renderer *renderer, Datas *datas, int *running):&#160;iMenu.c']]],
  ['menu_5finit',['menu_init',['../i_menu_8c.html#a816c438e50099982ccbb572c50e0dec4',1,'menu_init(Datas *datas):&#160;iMenu.c'],['../i_menu_8h.html#a816c438e50099982ccbb572c50e0dec4',1,'menu_init(Datas *datas):&#160;iMenu.c']]],
  ['menu_5fupdate',['menu_update',['../i_menu_8c.html#a032326a2bdb55ff1987d485d49b495d5',1,'menu_update(SDL_Window *windowP, SDL_Renderer *rendererP, Datas datas):&#160;iMenu.c'],['../i_menu_8h.html#a46a9351459e8c1009eb7e958369ab08d',1,'menu_update(SDL_Window *windowP, SDL_Renderer *renderer, Datas datas):&#160;iMenu.c']]],
  ['menu_5fupdate_5fbuttons',['menu_update_buttons',['../i_menu_8c.html#a3da60bd687ad2c5659c9992482ea8e44',1,'menu_update_buttons(SDL_Renderer *rendererP, Datas datas, int width, int height):&#160;iMenu.c'],['../i_menu_8h.html#a3da60bd687ad2c5659c9992482ea8e44',1,'menu_update_buttons(SDL_Renderer *rendererP, Datas datas, int width, int height):&#160;iMenu.c']]]
];
