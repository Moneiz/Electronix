var searchData=
[
  ['endapp',['endApp',['../kernel_8c.html#a2250bc04b5b91ffa33ebb43cd78d7862',1,'endApp(SDL_Window *windowP, SDL_Renderer *rendererP, Datas datas, Ressources r):&#160;kernel.c'],['../kernel_8h.html#a2250bc04b5b91ffa33ebb43cd78d7862',1,'endApp(SDL_Window *windowP, SDL_Renderer *rendererP, Datas datas, Ressources r):&#160;kernel.c']]],
  ['errmemoryunalloc',['errMemoryUnalloc',['../kernel_8c.html#a65451e64eb3547a8abe80f349a2f03f4',1,'errMemoryUnalloc(int sizeByte):&#160;kernel.c'],['../kernel_8h.html#a65451e64eb3547a8abe80f349a2f03f4',1,'errMemoryUnalloc(int sizeByte):&#160;kernel.c']]]
];
