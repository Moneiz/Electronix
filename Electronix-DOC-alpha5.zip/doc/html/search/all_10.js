var searchData=
[
  ['savecircuit',['saveCircuit',['../saveload_8c.html#aa828efb8d6104df27f1589f7827b8ea2',1,'saveCircuit(char *filename, Datas datas):&#160;saveload.c'],['../saveload_8h.html#aa828efb8d6104df27f1589f7827b8ea2',1,'saveCircuit(char *filename, Datas datas):&#160;saveload.c']]],
  ['saveload_2ec',['saveload.c',['../saveload_8c.html',1,'']]],
  ['saveload_2eh',['saveload.h',['../saveload_8h.html',1,'']]],
  ['savespath',['savesPath',['../struct_config.html#adc6000951d279f41265d132f8926a4fb',1,'Config']]],
  ['selectedcomponent',['selectedComponent',['../struct_grid___manager.html#ae0966c1547e744296b203db2c0d06abe',1,'Grid_Manager']]],
  ['setcolorfromint',['setColorFromInt',['../m_resistor_8c.html#afaf7cc57d33a59099c3bc467b40b984e',1,'setColorFromInt(SDL_Renderer *renderP, int colorCode):&#160;mResistor.c'],['../m_resistor_8h.html#afaf7cc57d33a59099c3bc467b40b984e',1,'setColorFromInt(SDL_Renderer *renderP, int colorCode):&#160;mResistor.c']]],
  ['setspecificdatacomponent',['setSpecificDataComponent',['../list_helper_8c.html#aef6a1c2c2de1abc2df4156b5bad5d1ca',1,'setSpecificDataComponent(Datas *datas, int id, double value):&#160;listHelper.c'],['../list_helper_8h.html#aef6a1c2c2de1abc2df4156b5bad5d1ca',1,'setSpecificDataComponent(Datas *datas, int id, double value):&#160;listHelper.c']]],
  ['showbtmodule',['showBtModule',['../module_loader_8c.html#a271568395f451cef5ad305bf3fd4440b',1,'showBtModule(SDL_Renderer *rendererP, SDL_Rect currentMod, Datas datas, int id):&#160;moduleLoader.c'],['../module_loader_8h.html#a271568395f451cef5ad305bf3fd4440b',1,'showBtModule(SDL_Renderer *rendererP, SDL_Rect currentMod, Datas datas, int id):&#160;moduleLoader.c']]],
  ['specificdata',['specificData',['../struct_component.html#a45788d4c064f4b541e79c588e5355402',1,'Component']]],
  ['statemodule',['stateModule',['../struct_component.html#aea055f43cfad2f78accfbc769ff874bb',1,'Component']]],
  ['substring',['subString',['../config_8c.html#a5848ec1e63b47e154987ea85bba1fffb',1,'config.c']]],
  ['surfaces_5fmanager',['Surfaces_manager',['../struct_surfaces__manager.html',1,'Surfaces_manager'],['../surfaces_manager_8h.html#ac3182859d8ea39776348e02b179b8c36',1,'Surfaces_manager():&#160;surfacesManager.h']]],
  ['surfacesmanager_2ec',['surfacesManager.c',['../surfaces_manager_8c.html',1,'']]],
  ['surfacesmanager_2eh',['surfacesManager.h',['../surfaces_manager_8h.html',1,'']]]
];
