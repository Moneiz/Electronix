var searchData=
[
  ['savecircuit',['saveCircuit',['../saveload_8c.html#aa828efb8d6104df27f1589f7827b8ea2',1,'saveCircuit(char *filename, Datas datas):&#160;saveload.c'],['../saveload_8h.html#aa828efb8d6104df27f1589f7827b8ea2',1,'saveCircuit(char *filename, Datas datas):&#160;saveload.c']]],
  ['setcolorfromint',['setColorFromInt',['../m_resistor_8c.html#afaf7cc57d33a59099c3bc467b40b984e',1,'setColorFromInt(SDL_Renderer *renderP, int colorCode):&#160;mResistor.c'],['../m_resistor_8h.html#afaf7cc57d33a59099c3bc467b40b984e',1,'setColorFromInt(SDL_Renderer *renderP, int colorCode):&#160;mResistor.c']]],
  ['setspecificdatacomponent',['setSpecificDataComponent',['../list_helper_8c.html#aef6a1c2c2de1abc2df4156b5bad5d1ca',1,'setSpecificDataComponent(Datas *datas, int id, double value):&#160;listHelper.c'],['../list_helper_8h.html#aef6a1c2c2de1abc2df4156b5bad5d1ca',1,'setSpecificDataComponent(Datas *datas, int id, double value):&#160;listHelper.c']]],
  ['showbtmodule',['showBtModule',['../module_loader_8c.html#a271568395f451cef5ad305bf3fd4440b',1,'showBtModule(SDL_Renderer *rendererP, SDL_Rect currentMod, Datas datas, int id):&#160;moduleLoader.c'],['../module_loader_8h.html#a271568395f451cef5ad305bf3fd4440b',1,'showBtModule(SDL_Renderer *rendererP, SDL_Rect currentMod, Datas datas, int id):&#160;moduleLoader.c']]],
  ['substring',['subString',['../config_8c.html#a5848ec1e63b47e154987ea85bba1fffb',1,'config.c']]]
];
