var searchData=
[
  ['textures_5fmanager',['Textures_manager',['../struct_textures__manager.html',1,'']]]
];
