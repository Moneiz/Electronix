var searchData=
[
  ['maximized',['maximized',['../struct_config.html#a8b8cd3b4776be76d54c83f333b99009f',1,'Config']]]
];
