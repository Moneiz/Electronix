var searchData=
[
  ['onclickcomponent',['onClickComponent',['../module_loader_8c.html#ab7b95e61e5edfa939bcd79d247a2afa5',1,'onClickComponent(SDL_MouseButtonEvent mEvent, Datas *datas, Component component):&#160;moduleLoader.c'],['../module_loader_8h.html#ab7b95e61e5edfa939bcd79d247a2afa5',1,'onClickComponent(SDL_MouseButtonEvent mEvent, Datas *datas, Component component):&#160;moduleLoader.c']]]
];
