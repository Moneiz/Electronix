var searchData=
[
  ['turninfo',['turnInfo',['../m_resistor_8c.html#af41454cc90722a02143d3f44314581dc',1,'turnInfo(int size, SDL_Rect currentComp, SDL_Rect *bar):&#160;mResistor.c'],['../m_resistor_8h.html#af41454cc90722a02143d3f44314581dc',1,'turnInfo(int size, SDL_Rect currentComp, SDL_Rect *bar):&#160;mResistor.c']]]
];
