var searchData=
[
  ['grid_5fmanager',['Grid_Manager',['../struct_grid___manager.html',1,'']]]
];
