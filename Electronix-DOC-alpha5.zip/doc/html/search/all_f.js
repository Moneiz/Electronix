var searchData=
[
  ['rectbt',['rectBt',['../struct_u_i__manager.html#a1e14e727e29eaca7cf3f697b4496d83d',1,'UI_manager']]],
  ['rectgroup',['rectGroup',['../struct_u_i__manager.html#a459174f6e9f0f0501699660adb7d038d',1,'UI_manager']]],
  ['redrawtext',['redrawText',['../layout_loader_8c.html#acccde83ff917faf1fff4accb7f20c4f3',1,'redrawText(SDL_Renderer *rendererP, Datas *datas, int ptrText, char *newText, int codeColor):&#160;layoutLoader.c'],['../layout_loader_8h.html#acccde83ff917faf1fff4accb7f20c4f3',1,'redrawText(SDL_Renderer *rendererP, Datas *datas, int ptrText, char *newText, int codeColor):&#160;layoutLoader.c']]],
  ['removeall',['removeAll',['../list_helper_8c.html#a6b78618d28f263e078bd1e768ca0389e',1,'listHelper.c']]],
  ['removecomponentongrid',['removeComponentOnGrid',['../module_loader_8c.html#a73e12b4757f64e53c9420234dce60d43',1,'removeComponentOnGrid(Datas *datas, Component component):&#160;moduleLoader.c'],['../module_loader_8h.html#a73e12b4757f64e53c9420234dce60d43',1,'removeComponentOnGrid(Datas *datas, Component component):&#160;moduleLoader.c']]],
  ['removeitem',['removeItem',['../list_helper_8c.html#ac9c8ba302af45e96ae2b43a3ecab4865',1,'listHelper.c']]],
  ['removeitemat',['removeItemAt',['../list_helper_8c.html#af0f01c2dbe574864203f6afb6ff1b14f',1,'removeItemAt(ItemComponent *start, int id):&#160;listHelper.c'],['../list_helper_8h.html#af0f01c2dbe574864203f6afb6ff1b14f',1,'removeItemAt(ItemComponent *start, int id):&#160;listHelper.c']]],
  ['rendercomponents',['renderComponents',['../module_loader_8c.html#a6088b440d16b6b9da4c2e34817619d5c',1,'renderComponents(SDL_Renderer *rendererP, Datas datas):&#160;moduleLoader.c'],['../module_loader_8h.html#a6088b440d16b6b9da4c2e34817619d5c',1,'renderComponents(SDL_Renderer *rendererP, Datas datas):&#160;moduleLoader.c']]],
  ['resistor_5fdrawcomponent',['resistor_drawComponent',['../m_resistor_8c.html#a23fc8b451a3aca15e5bff60c7814f87e',1,'resistor_drawComponent(SDL_Rect currentRect, Component currentComponent, int idTex, SDL_Renderer *rendererP, Datas datas):&#160;mResistor.c'],['../m_resistor_8h.html#a23fc8b451a3aca15e5bff60c7814f87e',1,'resistor_drawComponent(SDL_Rect currentRect, Component currentComponent, int idTex, SDL_Renderer *rendererP, Datas datas):&#160;mResistor.c']]],
  ['ressources_2ec',['ressources.c',['../ressources_8c.html',1,'']]],
  ['ressources_2eh',['ressources.h',['../ressources_8h.html',1,'']]],
  ['reversecomponent',['reverseComponent',['../list_helper_8c.html#aed5b7d602616f1215e639c06ac7d2445',1,'reverseComponent(Datas *datas, int id):&#160;listHelper.c'],['../list_helper_8h.html#aed5b7d602616f1215e639c06ac7d2445',1,'reverseComponent(Datas *datas, int id):&#160;listHelper.c']]]
];
