var searchData=
[
  ['texts',['texts',['../struct_surfaces__manager.html#abb899f2a19b54bc285f90ae8f8e5b3e6',1,'Surfaces_manager::texts()'],['../struct_textures__manager.html#a61c8d120bd02069e531423244e97dff3',1,'Textures_manager::texts()']]]
];
