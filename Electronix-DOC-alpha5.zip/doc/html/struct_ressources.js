var struct_ressources =
[
    [ "appVersion", "struct_ressources.html#a8781050ab3080072c77cda4c93548a7f", null ],
    [ "config", "struct_ressources.html#a4a8dd3a2de125b72d4fe6251a0a271b5", null ],
    [ "font", "struct_ressources.html#aade1edee5b4434ae7ebbeb64eb114f0f", null ],
    [ "listImgFiles", "struct_ressources.html#a2da21db52ffdf16d6cae9f4af317dfa2", null ],
    [ "listText", "struct_ressources.html#ac4cd0239218fa3170b8280b311b8b254", null ],
    [ "sizeListImgFiles", "struct_ressources.html#a198db8cadfeb946ada6c81246e43635b", null ],
    [ "sizeListText", "struct_ressources.html#a36fc53ddca3bce1833b02f567aeda2f7", null ]
];