var kernel_8h =
[
    [ "endApp", "kernel_8h.html#a2250bc04b5b91ffa33ebb43cd78d7862", null ],
    [ "errMemoryUnalloc", "kernel_8h.html#a65451e64eb3547a8abe80f349a2f03f4", null ],
    [ "freeRessources", "kernel_8h.html#a27352a8c81f0f38a3d466b5f43eef351", null ],
    [ "init", "kernel_8h.html#ab2d3e07493013fd0d4a5d15f84527c76", null ],
    [ "initImg", "kernel_8h.html#a79611f01731f7d59e7578f9542856c76", null ],
    [ "initRenderer", "kernel_8h.html#a11c40bc21fd18f241dc553a7cfdd25ce", null ],
    [ "initTtf", "kernel_8h.html#afca2db4659badc3ec302baecfed01c4c", null ],
    [ "initWindow", "kernel_8h.html#a689eac01d794a7742f08775452233a1b", null ],
    [ "postInit", "kernel_8h.html#aefe5df88c57d4b9a356721c015cf1fd6", null ],
    [ "updateApp", "kernel_8h.html#a7c80e5cba74a4b6b33813ff506b517ab", null ]
];