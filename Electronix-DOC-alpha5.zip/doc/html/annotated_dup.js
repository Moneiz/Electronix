var annotated_dup =
[
    [ "Component", "struct_component.html", "struct_component" ],
    [ "Config", "struct_config.html", "struct_config" ],
    [ "Grid_Manager", "struct_grid___manager.html", "struct_grid___manager" ],
    [ "ItemComponent", "struct_item_component.html", "struct_item_component" ],
    [ "Module", "struct_module.html", "struct_module" ],
    [ "Surfaces_manager", "struct_surfaces__manager.html", "struct_surfaces__manager" ],
    [ "Textures_manager", "struct_textures__manager.html", "struct_textures__manager" ],
    [ "UI_manager", "struct_u_i__manager.html", "struct_u_i__manager" ]
];