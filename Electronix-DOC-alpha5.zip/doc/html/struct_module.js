var struct_module =
[
    [ "id", "struct_module.html#a7441ef0865bcb3db9b8064dd7375c1ea", null ],
    [ "idTex", "struct_module.html#ab13ec74881a98fe9d28c5061ded2dfc3", null ],
    [ "idTextTex", "struct_module.html#a5c82eb5122f6823fe5a335b1fa92c4fc", null ],
    [ "nbLink", "struct_module.html#ac1ec258f4c84ddbb1a16a50266eeb0c1", null ],
    [ "ptrFctCalculate", "struct_module.html#ad12c3e73115b0d819ec4933d324757de", null ],
    [ "ptrFctRender", "struct_module.html#a7a2639b6dbb59b82a9e0c2e6dc6b48da", null ]
];