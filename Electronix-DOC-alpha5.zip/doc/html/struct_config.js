var struct_config =
[
    [ "downChoose", "struct_config.html#a2067791600b8b0e36963e29bd61391f1", null ],
    [ "fontsPath", "struct_config.html#a270f55e1d49965f2da6760f335fb9eb7", null ],
    [ "fullscreen", "struct_config.html#adc359d0ba0a207e69da999c40bf762c8", null ],
    [ "height", "struct_config.html#ad12fc34ce789bce6c8a05d8a17138534", null ],
    [ "imgPath", "struct_config.html#a805290e37db3d38fd0cb6b1203b38f38", null ],
    [ "maximized", "struct_config.html#a8b8cd3b4776be76d54c83f333b99009f", null ],
    [ "navDown", "struct_config.html#a6009dd35a214e407ad3947c21d2804f9", null ],
    [ "navLeft", "struct_config.html#a8dfc764cb6f9c1b5ef745b06252f528c", null ],
    [ "navRigth", "struct_config.html#a4a942736f900ded759a1be0566f4bd93", null ],
    [ "navUp", "struct_config.html#a85d9bed001ec51a16c7c65c316518a7c", null ],
    [ "savesPath", "struct_config.html#adc6000951d279f41265d132f8926a4fb", null ],
    [ "upChoose", "struct_config.html#a00b8c17a020358009c38f139be002545", null ],
    [ "width", "struct_config.html#a2474a5474cbff19523a51eb1de01cda4", null ]
];