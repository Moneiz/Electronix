var struct_textures__manager =
[
    [ "images", "struct_textures__manager.html#abf19338263969e06c736f02b97767e23", null ],
    [ "texts", "struct_textures__manager.html#a61c8d120bd02069e531423244e97dff3", null ]
];