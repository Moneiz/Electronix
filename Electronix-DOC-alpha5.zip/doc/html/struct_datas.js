var struct_datas =
[
    [ "currentIRenderFct", "struct_datas.html#aa14dd53fa95e12fd2151c78fc497e51d", null ],
    [ "font", "struct_datas.html#abf5bfa705e66ffc1ddaa6ce46c960873", null ],
    [ "projectName", "struct_datas.html#a0987198d0eb9259864b84810effffcc7", null ],
    [ "surfaces", "struct_datas.html#a530f19321a54449d2bff75f23be7eb17", null ],
    [ "textures", "struct_datas.html#a326b90d1d84f4776844934cfdf587f23", null ],
    [ "ui", "struct_datas.html#a77696cff220c0fb947084505103ced03", null ],
    [ "version", "struct_datas.html#a56abfaab87c46691c1ef3ad0df23e864", null ]
];