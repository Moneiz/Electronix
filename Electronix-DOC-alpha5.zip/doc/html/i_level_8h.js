var i_level_8h =
[
    [ "level_end", "i_level_8h.html#ab674392fdf2fa43404f751473757400d", null ],
    [ "level_event", "i_level_8h.html#a7671cb53210f09075bd23779cbe6abe2", null ],
    [ "level_init", "i_level_8h.html#a65ed4ac2dfd6ec71ae8d8cdab9395e12", null ],
    [ "level_update", "i_level_8h.html#a7bc2ea82fc31238bf6e439cc5e3a8925", null ],
    [ "level_update_buttons", "i_level_8h.html#a66fecb58be837baa006a0db2da691e68", null ]
];