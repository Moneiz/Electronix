var i_menu_8c =
[
    [ "menu_end", "i_menu_8c.html#a16c79ce4eea6a9286541a3c2447ecd1b", null ],
    [ "menu_event", "i_menu_8c.html#aa8142218663330ead3358c75506cadde", null ],
    [ "menu_init", "i_menu_8c.html#a816c438e50099982ccbb572c50e0dec4", null ],
    [ "menu_update", "i_menu_8c.html#a032326a2bdb55ff1987d485d49b495d5", null ],
    [ "menu_update_buttons", "i_menu_8c.html#a3da60bd687ad2c5659c9992482ea8e44", null ]
];