var m_resistor_8c =
[
    [ "resistor_drawComponent", "m_resistor_8c.html#a23fc8b451a3aca15e5bff60c7814f87e", null ],
    [ "setColorFromInt", "m_resistor_8c.html#afaf7cc57d33a59099c3bc467b40b984e", null ],
    [ "turnInfo", "m_resistor_8c.html#af41454cc90722a02143d3f44314581dc", null ],
    [ "valueToColor", "m_resistor_8c.html#aaded36efbd6f3e08812954202374ef35", null ]
];