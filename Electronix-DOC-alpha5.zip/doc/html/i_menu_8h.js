var i_menu_8h =
[
    [ "menu_end", "i_menu_8h.html#a16c79ce4eea6a9286541a3c2447ecd1b", null ],
    [ "menu_event", "i_menu_8h.html#a546546b61fc8e75b1caa83941f1282ce", null ],
    [ "menu_init", "i_menu_8h.html#a816c438e50099982ccbb572c50e0dec4", null ],
    [ "menu_update", "i_menu_8h.html#a46a9351459e8c1009eb7e958369ab08d", null ],
    [ "menu_update_buttons", "i_menu_8h.html#a3da60bd687ad2c5659c9992482ea8e44", null ]
];