var struct_surfaces__manager =
[
    [ "images", "struct_surfaces__manager.html#a943d5f0bb9d3fae424c9fd4072e43078", null ],
    [ "nbImg", "struct_surfaces__manager.html#aeb3196ea444a9d76c43c4eb23120d010", null ],
    [ "nbText", "struct_surfaces__manager.html#a6ad03983a7becedbc265fb4408426bfc", null ],
    [ "texts", "struct_surfaces__manager.html#abb899f2a19b54bc285f90ae8f8e5b3e6", null ]
];