var surfaces_manager_8h =
[
    [ "Surfaces_manager", "struct_surfaces__manager.html", "struct_surfaces__manager" ],
    [ "Surfaces_manager", "surfaces_manager_8h.html#ac3182859d8ea39776348e02b179b8c36", null ]
];