var struct_component =
[
    [ "id", "struct_component.html#a2e74aff868562e644e5d582929433363", null ],
    [ "idModule", "struct_component.html#a4cee636e799633e01509457f10664e37", null ],
    [ "isReversed", "struct_component.html#a1da8a5d0bc37fdc2f93ec1d4503f1d17", null ],
    [ "posX", "struct_component.html#a767e5fff82d910cc62dbb32105a831be", null ],
    [ "posY", "struct_component.html#a1a549fe2e17a9141ee8b37f062491c11", null ],
    [ "specificData", "struct_component.html#a45788d4c064f4b541e79c588e5355402", null ],
    [ "stateModule", "struct_component.html#aea055f43cfad2f78accfbc769ff874bb", null ]
];