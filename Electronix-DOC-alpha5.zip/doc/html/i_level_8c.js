var i_level_8c =
[
    [ "level_end", "i_level_8c.html#ab674392fdf2fa43404f751473757400d", null ],
    [ "level_event", "i_level_8c.html#ab8f8c7f3e8b841274746187613a5eb14", null ],
    [ "level_init", "i_level_8c.html#a65ed4ac2dfd6ec71ae8d8cdab9395e12", null ],
    [ "level_update", "i_level_8c.html#a724125aedba7691500edefe87a30bf9c", null ],
    [ "level_update_buttons", "i_level_8c.html#a66fecb58be837baa006a0db2da691e68", null ]
];