var m_generator_8c =
[
    [ "generator_calculate", "m_generator_8c.html#a44524c12752a26c9c2138da2b9642ddf", null ],
    [ "generator_drawComponent", "m_generator_8c.html#ab708f4885fb68e80b6ad0776ce952f69", null ]
];