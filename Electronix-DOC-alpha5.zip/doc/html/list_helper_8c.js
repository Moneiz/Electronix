var list_helper_8c =
[
    [ "addItem", "list_helper_8c.html#a60d97bd161317b13f80d773b276e2226", null ],
    [ "getComponentById", "list_helper_8c.html#a8da428b03fd84401f57716effd0e491f", null ],
    [ "getComponentByPos", "list_helper_8c.html#a70142d1f266116b07a823feec0979f9b", null ],
    [ "listToArray", "list_helper_8c.html#a2ebb421af0889e87c8793704b57a9d9b", null ],
    [ "removeAll", "list_helper_8c.html#a6b78618d28f263e078bd1e768ca0389e", null ],
    [ "removeItem", "list_helper_8c.html#ac9c8ba302af45e96ae2b43a3ecab4865", null ],
    [ "removeItemAt", "list_helper_8c.html#af0f01c2dbe574864203f6afb6ff1b14f", null ],
    [ "reverseComponent", "list_helper_8c.html#aed5b7d602616f1215e639c06ac7d2445", null ],
    [ "setSpecificDataComponent", "list_helper_8c.html#aef6a1c2c2de1abc2df4156b5bad5d1ca", null ]
];